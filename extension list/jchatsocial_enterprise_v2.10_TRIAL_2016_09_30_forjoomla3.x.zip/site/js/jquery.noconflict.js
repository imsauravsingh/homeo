/**
 * No conflict mode
 */
jQuery.noConflict();