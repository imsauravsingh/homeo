DROP TABLE IF EXISTS `#__jchat`; 

DROP TABLE IF EXISTS `#__jchat_sessionstatus`; 

DROP TABLE IF EXISTS `#__jchat_userstatus`; 

DROP TABLE IF EXISTS `#__jchat_public_sessionrelations`; 

DROP TABLE IF EXISTS `#__jchat_public_readmessages`; 

DROP TABLE IF EXISTS `#__jchat_rooms`; 

DROP TABLE IF EXISTS `#__jchat_banned_users`;

DROP TABLE IF EXISTS `#__jchat_webrtc`;

DROP TABLE IF EXISTS `#__jchat_webrtc_conference`;

DROP TABLE IF EXISTS `#__jchat_lamessages`;

DROP TABLE IF EXISTS `#__jchat_messaging_deletedmessages`;

DROP TABLE IF EXISTS `#__jchat_login`;

DROP TABLE IF EXISTS `#__jchat_emoticons`;

DROP TABLE IF EXISTS `#__jchat_recordings`;

