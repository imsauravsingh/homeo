DROP TABLE IF EXISTS `#__pbbooking_block_days`;
DROP TABLE IF EXISTS `#__pbbooking_cals`;
DROP TABLE IF EXISTS `#__pbbooking_config`;
DROP TABLE IF EXISTS `#__pbbooking_customfields`;
DROP TABLE IF EXISTS `#__pbbooking_customfields_data`;
DROP TABLE IF EXISTS `#__pbbooking_events`;
DROP TABLE IF EXISTS `#__pbbooking_pending`;
DROP TABLE IF EXISTS `#__pbbooking_treatments`;