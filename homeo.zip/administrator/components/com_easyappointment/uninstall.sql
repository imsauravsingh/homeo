DROP TABLE IF EXISTS `#__make_appointment_payments`;
DROP TABLE IF EXISTS `#__make_appointment_reservations`;
DROP TABLE IF EXISTS `#__make_appointment_services`;
DROP TABLE IF EXISTS `#__make_appointment_staff`;
