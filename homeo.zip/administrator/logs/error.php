#
#<?php die('Forbidden.'); ?>
#Date: 2016-08-27 10:34:11 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2016-08-27T10:34:11+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-03T14:19:31+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-03T14:46:05+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-04T08:07:37+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-04T12:23:53+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-04T12:26:39+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-04T12:27:31+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-04T12:31:21+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-04T12:31:47+00:00	INFO ::1	joomlafailure	Username and password do not match or you do not have an account yet.
2016-09-17T07:30:00+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
